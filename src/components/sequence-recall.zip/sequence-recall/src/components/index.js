import React from "react";
import ReactDOM from "react-dom/client";


// Mount the React app to the `#app` div in `public/index.html`
const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App />);
